import axios from 'axios';
import { LoginCredentials, AuthResponse } from '../types/auth.types';

const API_BASE_URL = '/api';

// Mock API service for authentication
export const authService = {
  // Mock login function - returns a mock token
  login: async (credentials: LoginCredentials): Promise<AuthResponse> => {
    try {
      // In a real app, this would make an actual API call
      // const response = await axios.post(`${API_BASE_URL}/auth/login`, credentials);
      // return response.data;

      // Mock response - simulate API delay
      await new Promise(resolve => setTimeout(resolve, 500));

      // Simple validation
      if (!credentials.email || !credentials.password) {
        throw new Error('Email and password are required');
      }

      // Mock successful login
      return {
        token: 'mock-token-' + Date.now(),
        user: {
          id: '1',
          email: credentials.email,
          name: credentials.email.split('@')[0],
        },
      };
    } catch (error) {
      if (axios.isAxiosError(error)) {
        throw new Error(error.response?.data?.message || 'Login failed');
      }
      throw error;
    }
  },

  // Get current user (not implemented in mock)
  getCurrentUser: async (token: string) => {
    // In a real app, you would validate the token with the backend
    // const response = await axios.get(`${API_BASE_URL}/auth/me`, {
    //   headers: { Authorization: `Bearer ${token}` }
    // });
    // return response.data;
    return null;
  },
};

// Token management utilities
export const tokenStorage = {
  getToken: (): string | null => {
    return localStorage.getItem('auth_token');
  },

  setToken: (token: string): void => {
    localStorage.setItem('auth_token', token);
  },

  removeToken: (): void => {
    localStorage.removeItem('auth_token');
  },
};
